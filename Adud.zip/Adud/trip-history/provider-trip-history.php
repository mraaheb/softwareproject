<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "provider") {
    header("Location: ../login/login.php");
    exit;
}

$full_name = $_SESSION["full_name"] ?? "Provider";
$user_id = (int)($_SESSION["user_id"] ?? 0);

$status_filter = $_GET["status"] ?? "";
$date_filter = $_GET["date"] ?? "";
$destination_filter = $_GET["destination"] ?? "";

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function statusClass($status) {
    return ($status === "Completed") ? "pill-completed" : "pill-cancelled";
}

$destinations = [];

$dest_stmt = $conn->prepare("
    SELECT DISTINCT destination
    FROM requests
    WHERE provider_id = ?
      AND destination IS NOT NULL
      AND destination != ''
    ORDER BY destination ASC
");
$dest_stmt->bind_param("i", $user_id);
$dest_stmt->execute();
$dest_result = $dest_stmt->get_result();

while ($row = $dest_result->fetch_assoc()) {
    $destinations[] = $row["destination"];
}
$dest_stmt->close();

$trips = [];

$sql = "
SELECT
    r.id,
    r.pickup_location,
    r.destination,
    r.appointment_datetime,
    r.created_at,
    r.status,
    r.wheelchair,
    r.oxygen,
    r.companion,
    pg.full_name AS patient_name,
    e.full_name AS escort_name
FROM requests r
INNER JOIN patient_guardians pg ON pg.id = r.patient_id
LEFT JOIN escorts e ON e.id = r.escort_id
WHERE r.provider_id = ?
";

$params = [$user_id];
$types = "i";

if ($date_filter !== "") {
    $start_date = $date_filter . " 00:00:00";
    $end_date   = $date_filter . " 23:59:59";

    $sql .= " AND r.created_at BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= "ss";
}

if ($status_filter !== "") {
    $sql .= " AND r.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

if ($destination_filter !== "") {
    $sql .= " AND r.destination = ?";
    $params[] = $destination_filter;
    $types .= "s";
}

$sql .= " ORDER BY r.created_at DESC, r.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $timeline = [];

    $timeline_stmt = $conn->prepare("
        SELECT status, created_at
        FROM trip_status
        WHERE request_id = ?
        ORDER BY id ASC
    ");
    $timeline_stmt->bind_param("i", $row["id"]);
    $timeline_stmt->execute();
    $timeline_result = $timeline_stmt->get_result();

    while ($tl = $timeline_result->fetch_assoc()) {
        $timeline[] = $tl;
    }

    $timeline_stmt->close();

    $row["timeline"] = $timeline;
    $trips[] = $row;
}

$stmt->close();

$avatar_letter = mb_substr($full_name, 0, 1);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adud — Provider Trip History</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="provider-trip-history.css?v=10">

<style>
.filter-form {
    display:flex;
    flex-wrap:wrap;
    gap:14px;
    align-items:flex-end;
    margin-bottom:22px;
    background:#fff;
    border:1px solid #e3e8e5;
    padding:18px;
    border-radius:16px;
    box-shadow:0 6px 18px rgba(31,44,37,.04);
}
.filter-box {
    display:flex;
    flex-direction:column;
    gap:6px;
}
.filter-box label {
    font-size:12px;
    font-weight:700;
    color:#5f6f66;
}
.filter-box input,
.filter-box select {
    height:42px;
    min-width:190px;
    padding:0 14px;
    border:1px solid #dfe7e2;
    border-radius:12px;
    background:#fff;
    font-family:'Tajawal',sans-serif;
    font-size:14px;
    color:#1f2c25;
    outline:none;
}
.filter-btn {
    height:42px;
    padding:0 18px;
    border:none;
    border-radius:12px;
    background:#2f6b4f;
    color:white;
    font-family:'Tajawal',sans-serif;
    font-size:14px;
    font-weight:700;
    cursor:pointer;
}
.clear-btn {
    height:42px;
    padding:0 18px;
    border-radius:12px;
    background:#eef3f0;
    color:#1f3d2b;
    font-size:14px;
    font-weight:700;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    text-decoration:none;
}
</style>
</head>

<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
    </div>

    <div class="provider-badge">🔑 Service Provider</div>

    <div class="nav-section">
        <div class="nav-section-label">Main / الرئيسية</div>

        <a class="nav-item" href="../provider-dashboard/provider-dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Provider Dashboard</span>
                <span class="label-ar">لوحة المزود</span>
            </div>
        </a>

        <a class="nav-item" href="../track-trip/provider-track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trip</span>
                <span class="label-ar">تتبع الرحلة</span>
            </div>
        </a>

        <a class="nav-item active" href="../trip-history/provider-trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الرحلات</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($avatar_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($full_name); ?></div>
                <div class="role">Service Provider ✓</div>
            </div>
        </div>

        <a class="logout-btn" href="../logout.php">🚪 Logout / تسجيل الخروج</a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div>
            <h1>Trip History / سجل الرحلات</h1>
            <p>Trips handled by this provider</p>
        </div>
    </div>

    <form method="GET" class="filter-form">
        <div class="filter-box">
            <label>Date / التاريخ</label>
            <input type="date" name="date" value="<?php echo h($date_filter); ?>">
        </div>

        <div class="filter-box">
            <label>Status / الحالة</label>
            <select name="status">
                <option value="">All Statuses</option>
                <option value="Requested" <?php if ($status_filter === "Requested") echo "selected"; ?>>Requested</option>
                <option value="Assigned" <?php if ($status_filter === "Assigned") echo "selected"; ?>>Assigned</option>
                <option value="Picked Up" <?php if ($status_filter === "Picked Up") echo "selected"; ?>>Picked Up</option>
                <option value="Arrived" <?php if ($status_filter === "Arrived") echo "selected"; ?>>Arrived</option>
                <option value="Completed" <?php if ($status_filter === "Completed") echo "selected"; ?>>Completed</option>
                <option value="Cancelled" <?php if ($status_filter === "Cancelled") echo "selected"; ?>>Cancelled</option>
                <option value="Rejected" <?php if ($status_filter === "Rejected") echo "selected"; ?>>Rejected</option>
            </select>
        </div>

        <div class="filter-box">
            <label>Destination / الوجهة</label>
            <select name="destination">
                <option value="">All Destinations</option>
                <?php foreach ($destinations as $destination): ?>
                    <option value="<?php echo h($destination); ?>" <?php if ($destination_filter === $destination) echo "selected"; ?>>
                        <?php echo h($destination); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="filter-btn">Filter</button>
        <a href="provider-trip-history.php" class="clear-btn">Clear</a>
    </form>

    <?php if (empty($trips)): ?>
        <div class="empty-state">
            <div class="empty-icon">📭</div>
            <h3>No provider trips found / لا توجد رحلات للمزود</h3>
            <p>There are no trips matching the selected filters.</p>
        </div>
    <?php else: ?>
        <div class="trips-list">
            <?php foreach ($trips as $trip): ?>
                <?php
                $meta = [];
                $meta[] = "Patient: " . ($trip["patient_name"] ?? "—");
                if (!empty($trip["wheelchair"])) $meta[] = "Wheelchair";
                if (!empty($trip["oxygen"])) $meta[] = "Oxygen";
                if (!empty($trip["companion"])) $meta[] = "Companion";
                if (!empty($trip["escort_name"])) $meta[] = "Escort: " . $trip["escort_name"];
                ?>

                <div class="trip-card">
                    <div class="trip-card-top">
                        <span class="trip-id">#<?php echo h($trip["id"]); ?></span>
                        <span class="trip-date">
                            Created: <?php echo h(date("Y-m-d", strtotime($trip["created_at"]))); ?>
                        </span>
                    </div>

                    <div class="trip-route">
                        <span class="route-point"><?php echo h($trip["pickup_location"]); ?></span>
                        <span class="route-arrow">→</span>
                        <span class="route-point"><?php echo h($trip["destination"]); ?></span>
                    </div>

                    <div class="trip-card-bottom">
                        <div class="trip-meta">
                            <span class="meta-chip">
                                Appointment: <?php echo h(date("Y-m-d h:i A", strtotime($trip["appointment_datetime"]))); ?>
                            </span>

                            <?php foreach ($meta as $chip): ?>
                                <span class="meta-chip"><?php echo h($chip); ?></span>
                            <?php endforeach; ?>
                        </div>

                        <span class="status-pill <?php echo statusClass($trip["status"]); ?>">
                            <span class="dot"></span>
                            <?php echo h($trip["status"]); ?>
                        </span>
                    </div>

                    <?php if (!empty($trip["timeline"])): ?>
                        <div class="timeline-box">
                            <div class="timeline-title">Timeline</div>
                            <div class="timeline-list">
                                <?php foreach ($trip["timeline"] as $item): ?>
                                    <div class="timeline-item">
                                        <div class="timeline-status"><?php echo h($item["status"]); ?></div>
                                        <div class="timeline-time">
                                            <?php echo h(date("Y-m-d h:i A", strtotime($item["created_at"]))); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

</body>
</html>