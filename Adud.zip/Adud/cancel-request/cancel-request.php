<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "patient") {
    header("Location: ../login/login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../dashboard/dashboard.php");
    exit;
}

$request_id = isset($_POST["request_id"]) ? (int) $_POST["request_id"] : 0;
$user_id = (int) $_SESSION["user_id"];

if ($request_id <= 0) {
    header("Location: ../dashboard/dashboard.php");
    exit;
}

/* نتأكد أن الطلب يخص المستخدم */
$check = $conn->prepare("
    SELECT status
    FROM requests
    WHERE id = ? AND patient_id = ?
    LIMIT 1
");
$check->bind_param("ii", $request_id, $user_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $status = trim($row["status"]);

    /* نسمح بالإلغاء فقط إذا الحالة Requested */
    if ($status === "Requested") {

        /* تحديث الحالة */
        $update = $conn->prepare("
            UPDATE requests
            SET status = 'Cancelled'
            WHERE id = ? AND patient_id = ?
        ");
        $update->bind_param("ii", $request_id, $user_id);
        $update->execute();
        $update->close();

        /* إضافة إلى trip_status */
        $insert_status = $conn->prepare("
            INSERT INTO trip_status (request_id, status, updated_by)
            VALUES (?, 'Cancelled', ?)
        ");
        $insert_status->bind_param("ii", $request_id, $user_id);
        $insert_status->execute();
        $insert_status->close();
    }
}

$check->close();

header("Location: ../dashboard/dashboard.php");
exit;