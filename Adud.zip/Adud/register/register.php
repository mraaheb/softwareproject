<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (isset($_SESSION["user_id"])) {
    if ($_SESSION["role"] === "provider") {
        header("Location: ../provider-dashboard/provider-dashboard.php");
    } else {
        header("Location: ../dashboard/dashboard.php");
    }
    exit;
}

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $full_name = trim($_POST["full_name"] ?? "");
    $role = trim($_POST["role"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = trim($_POST["password"] ?? "");
    $phone = trim($_POST["phone"] ?? "");

    if (empty($full_name) || empty($role) || empty($email) || empty($password)) {
        $message = "Please fill in all required fields / فضلاً عبّي كل الحقول المطلوبة";
        $message_type = "error";
    } else {

        if ($role === "patient") {

            if (empty($phone)) {
                $message = "Phone is required for patient / رقم الجوال مطلوب للمريض";
                $message_type = "error";
            } else {

                $wheelchair = isset($_POST["wheelchair"]) ? 1 : 0;
                $oxygen = isset($_POST["oxygen"]) ? 1 : 0;
                $companion = isset($_POST["companion"]) ? 1 : 0;
                $notes = "";

                $check = $conn->prepare("SELECT id FROM patient_guardians WHERE email = ?");
                if (!$check) {
                    die("Prepare failed: " . $conn->error);
                }

                $check->bind_param("s", $email);
                $check->execute();
                $result = $check->get_result();

                if ($result->num_rows > 0) {
                    $message = "This email is already registered / هذا البريد مسجل مسبقًا";
                    $message_type = "error";
                } else {

                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    $stmt = $conn->prepare("
                        INSERT INTO patient_guardians
                        (full_name, email, password, phone)
                        VALUES (?, ?, ?, ?)
                    ");

                    if (!$stmt) {
                        die("Prepare failed: " . $conn->error);
                    }

                    $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $phone);

                    if ($stmt->execute()) {

                        $patient_id = $stmt->insert_id;

                        $profile_stmt = $conn->prepare("
                            INSERT INTO profiles 
                            (patient_id, wheelchair, oxygen, companion, notes)
                            VALUES (?, ?, ?, ?, ?)
                        ");

                        if (!$profile_stmt) {
                            die("Prepare failed: " . $conn->error);
                        }

                        $profile_stmt->bind_param(
                            "iiiis",
                            $patient_id,
                            $wheelchair,
                            $oxygen,
                            $companion,
                            $notes
                        );

                        $profile_stmt->execute();
                        $profile_stmt->close();

                        $_SESSION["user_id"] = $patient_id;
                        $_SESSION["full_name"] = $full_name;
                        $_SESSION["email"] = $email;
                        $_SESSION["role"] = "patient";

                        header("Location: ../dashboard/dashboard.php");
                        exit;

                    } else {
                        die("Execute failed: " . $stmt->error);
                    }

                    $stmt->close();
                }

                $check->close();
            }

        } elseif ($role === "provider") {

            $check = $conn->prepare("SELECT id FROM service_providers WHERE email = ?");
            if (!$check) {
                die("Prepare failed: " . $conn->error);
            }

            $check->bind_param("s", $email);
            $check->execute();
            $result = $check->get_result();

            if ($result->num_rows > 0) {
                $message = "This email is already registered / هذا البريد مسجل مسبقًا";
                $message_type = "error";
            } else {

                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                /*
                  حسب جدولك الحالي:
                  id, full_name, email, password, provider_name,
                  license_number, is_verified, created_at
                */

                $provider_name = $full_name;
                $license_number = "LIC" . rand(1000, 9999);
                $is_verified = 1;

                $stmt = $conn->prepare("
                    INSERT INTO service_providers
                    (full_name, email, password, provider_name, license_number, is_verified)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                if (!$stmt) {
                    die("Prepare failed: " . $conn->error);
                }

                $stmt->bind_param(
                    "sssssi",
                    $full_name,
                    $email,
                    $hashed_password,
                    $provider_name,
                    $license_number,
                    $is_verified
                );

                if ($stmt->execute()) {

                    $provider_id = $stmt->insert_id;

                    $_SESSION["user_id"] = $provider_id;
                    $_SESSION["full_name"] = $full_name;
                    $_SESSION["email"] = $email;
                    $_SESSION["role"] = "provider";

                    header("Location: ../provider-dashboard/provider-dashboard.php");
                    exit;

                } else {
                    die("Execute failed: " . $stmt->error);
                }

                $stmt->close();
            }

            $check->close();

        } else {
            $message = "Invalid role / نوع الحساب غير صحيح";
            $message_type = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Adud — Register</title>

  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="register.css"/>
</head>

<body>

<div class="container">

  <div class="left">
    <div class="left-content">
      <img src="../images/logo.png" class="logo" alt="ADUD Logo"/>
      <p class="subtitle">Medical transport platform</p>
    </div>
  </div>

  <div class="right">
    <div class="form-box">

      <span class="form-tag">Register / إنشاء حساب</span>
      <h2>Create Account</h2>

      <?php if (!empty($message)): ?>
        <div class="<?php echo $message_type === 'success' ? 'success-message' : 'error-message'; ?>">
          <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>

      <form method="POST" action="">

        <label for="full_name">Full Name</label>
        <input
          type="text"
          id="full_name"
          name="full_name"
          value="<?php echo htmlspecialchars($_POST["full_name"] ?? ""); ?>"
          required
        />

        <label>Role</label>
        <div class="radio-group">

          <label class="radio-card">
            <input
              type="radio"
              name="role"
              value="patient"
              <?php echo (($_POST["role"] ?? "patient") === "patient") ? "checked" : ""; ?>
              required
            >
            <span>Patient</span>
          </label>

          <label class="radio-card">
            <input
              type="radio"
              name="role"
              value="provider"
              <?php echo (($_POST["role"] ?? "") === "provider") ? "checked" : ""; ?>
            >
            <span>Provider</span>
          </label>

        </div>

        <label for="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value="<?php echo htmlspecialchars($_POST["email"] ?? ""); ?>"
          required
        />

        <label for="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          required
        />

        <div id="patientFields">

          <label for="phone">Phone</label>
          <input
            type="text"
            id="phone"
            name="phone"
            value="<?php echo htmlspecialchars($_POST["phone"] ?? ""); ?>"
          />

          <div class="mini-title">Mobility Requirements</div>

          <div class="mobility-grid">

            <label class="mobility-card">
              <input type="checkbox" name="wheelchair" <?php echo isset($_POST["wheelchair"]) ? "checked" : ""; ?>>
              <div class="icon">♿</div>
              <div>Wheelchair</div>
            </label>

            <label class="mobility-card">
              <input type="checkbox" name="oxygen" <?php echo isset($_POST["oxygen"]) ? "checked" : ""; ?>>
              <div class="icon">🫁</div>
              <div>Oxygen</div>
            </label>

            <label class="mobility-card">
              <input type="checkbox" name="companion" <?php echo isset($_POST["companion"]) ? "checked" : ""; ?>>
              <div class="icon">🤝</div>
              <div>Companion</div>
            </label>

          </div>
        </div>

        <button type="submit">Register</button>

        <p class="link">
          Already have an account?
          <a href="../login/login.php">Login</a>
        </p>

      </form>

    </div>
  </div>

</div>

<script>
  const patientRadio = document.querySelector('input[name="role"][value="patient"]');
  const providerRadio = document.querySelector('input[name="role"][value="provider"]');
  const patientFields = document.getElementById("patientFields");
  const phoneInput = document.getElementById("phone");

  function toggleFields() {
    if (providerRadio.checked) {
      patientFields.style.display = "none";
      phoneInput.required = false;
      phoneInput.value = "";
    } else {
      patientFields.style.display = "block";
      phoneInput.required = true;
    }
  }

  patientRadio.addEventListener("change", toggleFields);
  providerRadio.addEventListener("change", toggleFields);

  toggleFields();
</script>

</body>
</html>