<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', '/adud'); 
date_default_timezone_set('Asia/Riyadh');
?>