<?php
require_once __DIR__ . "/../config.php";

function sanitizeInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header("Location: " . BASE_URL . "/" . ltrim($path, '/'));
    exit;
}

function isPostRequest() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}
?>