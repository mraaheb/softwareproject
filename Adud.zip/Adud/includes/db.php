<?php
$host = "localhost";
$dbname = "adud";
$username = "root";
$password = "root"; 
$port = 8889;        

$conn = new mysqli($host, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>