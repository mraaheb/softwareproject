<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Force HTTPS except localhost */
if (
    (empty($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] === "off") &&
    $_SERVER["HTTP_HOST"] !== "localhost:8888"
) {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit;
}

/* Session Timeout: 30 minutes */
$timeout_duration = 1800;

if (isset($_SESSION["LAST_ACTIVITY"])) {
    if (time() - $_SESSION["LAST_ACTIVITY"] > $timeout_duration) {
        session_unset();
        session_destroy();
        header("Location: ../login/login.php?timeout=1");
        exit;
    }
}

$_SESSION["LAST_ACTIVITY"] = time();

/* Regenerate Session ID every 30 minutes */
if (!isset($_SESSION["CREATED"])) {
    $_SESSION["CREATED"] = time();
} elseif (time() - $_SESSION["CREATED"] > 1800) {
    session_regenerate_id(true);
    $_SESSION["CREATED"] = time();
}
?>