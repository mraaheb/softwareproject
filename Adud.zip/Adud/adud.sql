-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 30, 2026 at 08:46 AM
-- Server version: 5.7.24
-- PHP Version: 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adud`
--

-- --------------------------------------------------------

--
-- Table structure for table `escorts`
--

CREATE TABLE `escorts` (
  `id` int(11) NOT NULL,
  `provider_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `notes` text,
  `is_available` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `escorts`
--

INSERT INTO `escorts` (`id`, `provider_id`, `full_name`, `phone`, `notes`, `is_available`, `created_at`) VALUES
(1, 1, 'Fay', '0551111111', 'Available for morning trips', 1, '2026-04-21 17:08:50'),
(2, 1, 'Hamoud', '0552222222', 'Can assist elderly patients', 1, '2026-04-21 17:08:50'),
(3, 1, 'Saad', '05556666', '', 1, '2026-04-21 17:35:07');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `patient_guardian_id` int(11) DEFAULT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `patient_guardian_id`, `provider_id`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 1, NULL, 'Your request has been created', 'request', 0, '2026-04-21 17:08:50'),
(2, NULL, 1, 'A new request is waiting for review', 'provider_alert', 0, '2026-04-21 17:08:50');

-- --------------------------------------------------------

--
-- Table structure for table `patient_guardians`
--

CREATE TABLE `patient_guardians` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient_guardians`
--

INSERT INTO `patient_guardians` (`id`, `full_name`, `email`, `password`, `phone`, `created_at`) VALUES
(1, 'Sara Ali', 'sara@test.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', '0501111111', '2026-04-21 17:08:49'),
(2, 'Maha Ahmed', 'maha@test.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', '0502222222', '2026-04-21 17:08:49'),
(3, 'Nora Barboud', 'nora@gmail.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', '05558401258', '2026-04-21 19:52:37'),
(4, 'FANAR', 'fanar@gmail.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', '05558401258', '2026-04-28 04:34:45');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `dob` date DEFAULT NULL,
  `wheelchair` tinyint(1) DEFAULT '0',
  `oxygen` tinyint(1) DEFAULT '0',
  `companion` tinyint(1) DEFAULT '0',
  `notes` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `patient_id`, `dob`, `wheelchair`, `oxygen`, `companion`, `notes`) VALUES
(1, 1, NULL, 1, 0, 1, 'Needs help entering vehicle'),
(2, 2, NULL, 0, 1, 0, 'Needs oxygen support'),
(3, 3, NULL, 1, 0, 1, ''),
(4, 4, NULL, 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `provider_id` int(11) DEFAULT NULL,
  `escort_id` int(11) DEFAULT NULL,
  `pickup_location` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `appointment_datetime` datetime NOT NULL,
  `wheelchair` tinyint(1) DEFAULT '0',
  `oxygen` tinyint(1) DEFAULT '0',
  `companion` tinyint(1) DEFAULT '0',
  `notes` text,
  `escort_required` tinyint(1) DEFAULT '0',
  `status` enum('Requested','Assigned','Picked Up','Arrived','Completed','Cancelled','Rejected') DEFAULT 'Requested',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `patient_id`, `provider_id`, `escort_id`, `pickup_location`, `destination`, `appointment_datetime`, `wheelchair`, `oxygen`, `companion`, `notes`, `escort_required`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 'Home', 'King Saud Medical City', '2026-04-22 10:00:00', 1, 0, 1, NULL, 1, 'Arrived', '2026-04-21 17:08:50', '2026-04-21 17:35:47'),
(2, 2, 1, 1, 'Clinic A', 'Hospital B', '2026-04-22 12:30:00', 0, 1, 0, NULL, 1, 'Cancelled', '2026-04-21 17:08:50', '2026-04-21 17:35:51'),
(3, 3, 1, NULL, 'king Saud unit', 'Dalla Namar', '2026-04-27 04:18:00', 1, 1, 0, '0', 1, 'Completed', '2026-04-21 22:19:12', '2026-04-22 11:18:43'),
(4, 3, NULL, NULL, 'Dallah', 'king', '2026-04-30 18:33:00', 1, 1, 1, 'i need help', 1, 'Cancelled', '2026-04-22 15:31:30', '2026-04-22 16:08:21'),
(5, 3, NULL, NULL, 'Dallah', 'home', '2026-04-27 12:13:00', 0, 1, 0, '', 0, 'Cancelled', '2026-04-22 16:08:56', '2026-04-22 16:09:02'),
(6, 3, 1, NULL, 'king Saud', 'king', '2026-04-25 20:23:00', 1, 1, 1, '', 0, 'Rejected', '2026-04-22 17:22:25', '2026-04-22 17:22:41'),
(7, 3, 1, 1, 'king Saud', 'king', '2026-05-07 21:13:00', 0, 1, 0, '', 0, 'Assigned', '2026-04-22 18:11:29', '2026-04-22 19:34:01'),
(8, 3, 1, 3, 'king Saud', 'tttt', '2026-05-07 21:14:00', 0, 0, 1, '', 0, 'Cancelled', '2026-04-22 18:11:45', '2026-04-30 07:36:33'),
(9, 3, 1, 2, 'gujgighig', 'hiihiihhi', '2026-05-06 15:15:00', 0, 0, 1, '', 1, 'Assigned', '2026-04-28 09:16:14', '2026-04-28 09:18:37'),
(10, 3, 1, NULL, 'king Saud unit', 'بيتنا', '2026-05-07 01:35:00', 1, 0, 0, '', 1, 'Assigned', '2026-04-30 06:35:44', '2026-04-30 07:35:53'),
(12, 3, 1, NULL, 'king Saud', 'king', '2026-04-30 10:36:00', 0, 0, 0, '', 1, 'Completed', '2026-04-30 07:35:04', '2026-04-30 07:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `service_providers`
--

CREATE TABLE `service_providers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `provider_name` varchar(100) DEFAULT NULL,
  `license_number` varchar(50) NOT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service_providers`
--

INSERT INTO `service_providers` (`id`, `full_name`, `email`, `password`, `provider_name`, `license_number`, `is_verified`, `created_at`) VALUES
(1, 'fanar Barboud', 'fanarad@gmail.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', 'fanar', 'LIC123', 1, '2026-04-21 17:08:49'),
(2, 'Ahmad Ail', 'ahmad@gmail.com', '$2y$10$CEx1msk9clmBis1eWgtC9utpbdFvkDwhLOA5BxH3KFkVLL0EsdQnu', 'Ahmad', 'LIC456', 1, '2026-04-21 17:08:49');

-- --------------------------------------------------------

--
-- Table structure for table `trip_history`
--

CREATE TABLE `trip_history` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `final_status` enum('Completed','Cancelled','Rejected') NOT NULL,
  `closed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `summary` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trip_history`
--

INSERT INTO `trip_history` (`id`, `request_id`, `final_status`, `closed_at`, `summary`) VALUES
(1, 2, 'Cancelled', '2026-04-21 17:35:51', 'Finalized by service provider'),
(2, 3, 'Completed', '2026-04-22 11:18:43', 'Finalized by service provider'),
(3, 6, 'Rejected', '2026-04-22 17:22:41', 'Finalized by service provider'),
(4, 12, 'Completed', '2026-04-30 07:36:28', 'Finalized by service provider'),
(5, 8, 'Cancelled', '2026-04-30 07:36:33', 'Finalized by service provider');

-- --------------------------------------------------------

--
-- Table structure for table `trip_status`
--

CREATE TABLE `trip_status` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `status` enum('Requested','Assigned','Picked Up','Arrived','Completed','Cancelled','Rejected') NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trip_status`
--

INSERT INTO `trip_status` (`id`, `request_id`, `status`, `updated_by`, `created_at`) VALUES
(1, 1, 'Requested', NULL, '2026-04-21 17:08:50'),
(2, 2, 'Assigned', 1, '2026-04-21 17:08:50'),
(3, 2, 'Assigned', 1, '2026-04-21 17:27:26'),
(4, 1, 'Assigned', 1, '2026-04-21 17:27:30'),
(5, 1, 'Arrived', 1, '2026-04-21 17:35:47'),
(6, 2, 'Cancelled', 1, '2026-04-21 17:35:51'),
(7, 3, 'Requested', 3, '2026-04-21 22:19:12'),
(8, 3, 'Assigned', 1, '2026-04-22 11:16:59'),
(9, 3, 'Completed', 1, '2026-04-22 11:18:43'),
(10, 4, 'Requested', 3, '2026-04-22 15:31:30'),
(11, 4, 'Cancelled', 3, '2026-04-22 16:08:21'),
(12, 5, 'Requested', 3, '2026-04-22 16:08:56'),
(13, 5, 'Cancelled', 3, '2026-04-22 16:09:02'),
(14, 6, 'Requested', 3, '2026-04-22 17:22:25'),
(15, 6, 'Rejected', 1, '2026-04-22 17:22:41'),
(16, 1, 'Arrived', 1, '2026-04-22 17:26:57'),
(17, 7, 'Requested', 3, '2026-04-22 18:11:29'),
(18, 8, 'Requested', 3, '2026-04-22 18:11:45'),
(19, 8, 'Assigned', 1, '2026-04-22 19:33:59'),
(20, 7, 'Assigned', 1, '2026-04-22 19:34:01'),
(21, 9, 'Requested', 3, '2026-04-28 09:16:14'),
(22, 9, 'Assigned', 1, '2026-04-28 09:18:37'),
(23, 10, 'Requested', 3, '2026-04-30 06:35:44'),
(25, 12, 'Requested', 3, '2026-04-30 07:35:04'),
(26, 12, 'Assigned', 1, '2026-04-30 07:35:51'),
(27, 10, 'Assigned', 1, '2026-04-30 07:35:53'),
(28, 12, 'Picked Up', 1, '2026-04-30 07:36:23'),
(29, 12, 'Completed', 1, '2026-04-30 07:36:28'),
(30, 8, 'Cancelled', 1, '2026-04-30 07:36:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `escorts`
--
ALTER TABLE `escorts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider_id` (`provider_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_guardian_id` (`patient_guardian_id`),
  ADD KEY `provider_id` (`provider_id`);

--
-- Indexes for table `patient_guardians`
--
ALTER TABLE `patient_guardians`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `provider_id` (`provider_id`),
  ADD KEY `escort_id` (`escort_id`);

--
-- Indexes for table `service_providers`
--
ALTER TABLE `service_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `trip_history`
--
ALTER TABLE `trip_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `trip_status`
--
ALTER TABLE `trip_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `escorts`
--
ALTER TABLE `escorts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `patient_guardians`
--
ALTER TABLE `patient_guardians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `service_providers`
--
ALTER TABLE `service_providers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trip_history`
--
ALTER TABLE `trip_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `trip_status`
--
ALTER TABLE `trip_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `escorts`
--
ALTER TABLE `escorts`
  ADD CONSTRAINT `escorts_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `service_providers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`patient_guardian_id`) REFERENCES `patient_guardians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `service_providers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_guardians` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_guardians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`provider_id`) REFERENCES `service_providers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `requests_ibfk_3` FOREIGN KEY (`escort_id`) REFERENCES `escorts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `trip_history`
--
ALTER TABLE `trip_history`
  ADD CONSTRAINT `trip_history_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `trip_status`
--
ALTER TABLE `trip_status`
  ADD CONSTRAINT `trip_status_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
