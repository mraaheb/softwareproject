<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "patient") {
    header("Location: ../login/login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$full_name = $_SESSION["full_name"] ?? "User";

$request_id = intval($_GET["id"] ?? 0);
$message = "";

if ($request_id <= 0) {
    header("Location: ../dashboard/dashboard.php");
    exit;
}

/* =========================
   GET REQUEST
========================= */
$stmt = $conn->prepare("
    SELECT * 
    FROM requests 
    WHERE id = ? AND patient_id = ?
");
$stmt->bind_param("ii", $request_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: ../dashboard/dashboard.php");
    exit;
}

$request = $result->fetch_assoc();
$stmt->close();

/* فقط الطلبات بحالة Requested تتعدل */
if ($request["status"] !== "Requested") {
    header("Location: ../dashboard/dashboard.php");
    exit;
}

/* =========================
   UPDATE
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $pickup = trim($_POST["pickup"] ?? "");
    $destination = trim($_POST["destination"] ?? "");
    $appt_date = trim($_POST["appt_date"] ?? "");
    $appt_time = trim($_POST["appt_time"] ?? "");

    $wheelchair = isset($_POST["wheelchair"]) ? 1 : 0;
    $oxygen = isset($_POST["oxygen"]) ? 1 : 0;
    $companion = isset($_POST["companion"]) ? 1 : 0;
    $escort_required = isset($_POST["escort_required"]) ? 1 : 0;

    if (empty($pickup) || empty($destination) || empty($appt_date) || empty($appt_time)) {
        $message = "Please fill all required fields / الرجاء تعبئة جميع الحقول المطلوبة";
    } else {
        $appointment_datetime = $appt_date . " " . $appt_time . ":00";

        $update = $conn->prepare("
            UPDATE requests SET
                pickup_location = ?,
                destination = ?,
                appointment_datetime = ?,
                wheelchair = ?,
                oxygen = ?,
                companion = ?,
                escort_required = ?
            WHERE id = ? AND patient_id = ?
        ");

        $update->bind_param(
            "sssiiiiii",
            $pickup,
            $destination,
            $appointment_datetime,
            $wheelchair,
            $oxygen,
            $companion,
            $escort_required,
            $request_id,
            $user_id
        );

        if ($update->execute()) {
            header("Location: ../dashboard/dashboard.php");
            exit;
        } else {
            $message = "Update failed / فشل التحديث";
        }

        $update->close();
    }
}

/* =========================
   SPLIT DATE/TIME
========================= */
$dt = strtotime($request["appointment_datetime"]);
$date = $dt ? date("Y-m-d", $dt) : "";
$time = $dt ? date("H:i", $dt) : "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Request - ADUD</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #1f3d2b;
            --primary: #2f6b4f;
            --primary-light: #5fa77d;
            --bg-soft: #f6f8f7;
            --white: #ffffff;
            --text-dark: #1f2c25;
            --text-mid: #5f6f66;
            --border: #e3e8e5;
            --danger-bg: #fdecec;
            --danger-text: #a33a3a;
            --danger-border: #f3c2c2;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: var(--bg-soft);
            color: var(--text-dark);
            min-height: 100vh;
            padding: 32px;
        }

        .page {
            max-width: 850px;
            margin: 0 auto;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .topbar h1 {
            font-size: 28px;
            font-weight: 800;
            color: var(--primary-dark);
        }

        .badge {
            background: #f5ecd9;
            color: var(--primary-dark);
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
        }

        .topbar-sub {
            font-size: 13px;
            color: var(--text-mid);
            margin-bottom: 24px;
        }

        .back-btn {
            display: inline-block;
            padding: 9px 14px;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            color: var(--text-dark);
            transition: 0.2s ease;
        }

        .back-btn:hover {
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }

        .card {
            background: var(--white);
            border-radius: 18px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(31, 44, 37, 0.05);
            border: 1px solid var(--border);
        }

        .error-message {
            background: var(--danger-bg);
            color: var(--danger-text);
            border: 1px solid var(--danger-border);
            padding: 12px 14px;
            border-radius: 12px;
            margin-bottom: 18px;
            font-size: 14px;
            font-weight: 600;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .field.full {
            grid-column: 1 / -1;
        }

        label {
            font-size: 14px;
            font-weight: 700;
            color: var(--text-dark);
        }

        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-family: inherit;
            font-size: 14px;
            outline: none;
            background: #fff;
        }

        input:focus {
            border-color: var(--primary-light);
        }

        .section-title {
            margin: 22px 0 12px;
            font-size: 15px;
            font-weight: 800;
            color: var(--primary-dark);
        }

        .checks {
            display: grid;
            grid-template-columns: repeat(2, minmax(180px, 1fr));
            gap: 12px;
        }

        .check-card {
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 14px;
            background: #fcfdfc;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .check-card input {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }

        .actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
            margin-top: 24px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 11px 18px;
            border-radius: 12px;
            font-family: inherit;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            border: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: #fff;
        }

        .btn-secondary {
            background: #f3f6f4;
            color: var(--text-dark);
            border: 1px solid var(--border);
        }

        @media (max-width: 700px) {
            body {
                padding: 18px;
            }

            .grid,
            .checks {
                grid-template-columns: 1fr;
            }

            .actions {
                flex-direction: column;
            }

            .btn,
            .back-btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<div class="page">
    <div class="topbar">
        <div class="topbar-left">
            <h1>Edit Request</h1>
            <span class="badge">Request</span>
        </div>

        <a class="back-btn" href="../dashboard/dashboard.php">← Back</a>
    </div>

    <p class="topbar-sub">
        Update your request details before it gets assigned / عدّل الطلب قبل ما يتم تعيينه
    </p>

    <div class="card">
        <?php if (!empty($message)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="grid">
                <div class="field full">
                    <label for="pickup">Pickup Location / موقع الاستلام</label>
                    <input
                        type="text"
                        id="pickup"
                        name="pickup"
                        value="<?php echo htmlspecialchars($_POST["pickup"] ?? $request["pickup_location"]); ?>"
                        required
                    >
                </div>

                <div class="field full">
                    <label for="destination">Destination / الوجهة</label>
                    <input
                        type="text"
                        id="destination"
                        name="destination"
                        value="<?php echo htmlspecialchars($_POST["destination"] ?? $request["destination"]); ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="appt_date">Date / التاريخ</label>
                    <input
                        type="date"
                        id="appt_date"
                        name="appt_date"
                        value="<?php echo htmlspecialchars($_POST["appt_date"] ?? $date); ?>"
                        required
                    >
                </div>

                <div class="field">
                    <label for="appt_time">Time / الوقت</label>
                    <input
                        type="time"
                        id="appt_time"
                        name="appt_time"
                        value="<?php echo htmlspecialchars($_POST["appt_time"] ?? $time); ?>"
                        required
                    >
                </div>
            </div>

            <div class="section-title">Mobility Requirements / متطلبات التنقل</div>

            <div class="checks">
                <label class="check-card">
                    <input
                        type="checkbox"
                        name="wheelchair"
                        <?php echo (isset($_POST["wheelchair"]) || (!$_POST && $request["wheelchair"])) ? "checked" : ""; ?>
                    >
                    <span>Wheelchair / كرسي متحرك</span>
                </label>

                <label class="check-card">
                    <input
                        type="checkbox"
                        name="oxygen"
                        <?php echo (isset($_POST["oxygen"]) || (!$_POST && $request["oxygen"])) ? "checked" : ""; ?>
                    >
                    <span>Oxygen / أكسجين</span>
                </label>

                <label class="check-card">
                    <input
                        type="checkbox"
                        name="companion"
                        <?php echo (isset($_POST["companion"]) || (!$_POST && $request["companion"])) ? "checked" : ""; ?>
                    >
                    <span>Companion / مرافق</span>
                </label>

                <label class="check-card">
                    <input
                        type="checkbox"
                        name="escort_required"
                        <?php echo (isset($_POST["escort_required"]) || (!$_POST && $request["escort_required"])) ? "checked" : ""; ?>
                    >
                    <span>Escort Required / يحتاج مرافق</span>
                </label>
            </div>

            <div class="actions">
                <a class="btn btn-secondary" href="../dashboard/dashboard.php">Cancel</a>
                <button class="btn btn-primary" type="submit">Update Request</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>