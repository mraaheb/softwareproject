<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $role = trim($_POST["role"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if (empty($role) || empty($email) || empty($password)) {
        $message = "Enter email and password / أدخل البريد وكلمة المرور";
    } else {
        if ($role === "provider") {
            $stmt = $conn->prepare("SELECT id, full_name, email, password FROM service_providers WHERE email = ?");
        } elseif ($role === "patient") {
            $stmt = $conn->prepare("SELECT id, full_name, email, password FROM patient_guardians WHERE email = ?");
        } else {
            $stmt = null;
            $message = "Invalid role / نوع الحساب غير صحيح";
        }

        if (empty($message)) {
            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $user = $result->fetch_assoc();

                if (password_verify($password, $user["password"])) {
                    session_regenerate_id(true);

                    $_SESSION["LAST_ACTIVITY"] = time();
                    $_SESSION["CREATED"] = time();

                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["full_name"] = $user["full_name"];
                    $_SESSION["email"] = $user["email"];
                    $_SESSION["role"] = $role;

                    if ($role === "provider") {
                        header("Location: ../provider-dashboard/provider-dashboard.php");
                    } else {
                        header("Location: ../dashboard/dashboard.php");
                    }
                    exit;
                } else {
                    $message = "Incorrect password / كلمة المرور غير صحيحة";
                }
            } else {
                $message = "User not found / المستخدم غير موجود";
            }

            $stmt->close();
        }
    }
}

if (isset($_GET["timeout"])) {
    $message = "Session expired. Please login again. / انتهت الجلسة، يرجى تسجيل الدخول مرة أخرى";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ADUD</title>

    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css">
</head>
<body>

<div class="container">

    <div class="left">
        <div class="left-content">
            <img src="../images/logo.png" class="logo" alt="ADUD Logo">
            <p class="subtitle">Medical transport platform</p>
        </div>
    </div>

    <div class="right">
        <div class="form-box">
            <span class="form-tag">Login / تسجيل الدخول</span>
            <h2>Welcome Back</h2>
            <p class="form-subtext">
                Sign in to access your account and continue managing your medical transport services.
            </p>

            <?php if (!empty($message)): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <label>Role</label>
                <div class="radio-group">
                    <label class="radio-card">
                        <input type="radio" name="role" value="patient"
                            <?php echo (($_POST["role"] ?? "") === "patient") ? "checked" : ""; ?>>
                        <span>Patient</span>
                    </label>

                    <label class="radio-card">
                        <input type="radio" name="role" value="provider"
                            <?php echo (($_POST["role"] ?? "") === "provider") ? "checked" : ""; ?>>
                        <span>Provider</span>
                    </label>
                </div>

                <label for="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?php echo htmlspecialchars($_POST["email"] ?? ""); ?>"
                    required
                >

                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >

                <button type="submit">Login</button>

                <p class="link">
                    Don't have an account?
                    <a href="../register/register.php">Register</a>
                </p>
            </form>
        </div>
    </div>

</div>

</body>
</html>