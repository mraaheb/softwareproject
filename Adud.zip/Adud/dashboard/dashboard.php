<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "patient") {
    header("Location: ../login/login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$full_name = $_SESSION["full_name"] ?? "User";
$email = $_SESSION["email"] ?? "";

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function statusClass($status) {
    switch ($status) {
        case "Requested":
            return "pill-requested";
        case "Assigned":
        case "Picked Up":
        case "Arrived":
            return "pill-active";
        case "Completed":
            return "pill-completed";
        case "Cancelled":
        case "Rejected":
            return "pill-cancelled";
        default:
            return "pill-default";
    }
}

/* =========================
   COUNTS
========================= */
$requested_count = 0;
$active_count = 0;
$completed_count = 0;
$cancelled_count = 0;

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM requests
    WHERE patient_id = ? AND status = 'Requested'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$requested_count = (int)($res["total"] ?? 0);
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM requests
    WHERE patient_id = ? AND status IN ('Assigned', 'Picked Up', 'Arrived')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$active_count = (int)($res["total"] ?? 0);
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM requests
    WHERE patient_id = ? AND status = 'Completed'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$completed_count = (int)($res["total"] ?? 0);
$stmt->close();

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM requests
    WHERE patient_id = ? AND status IN ('Cancelled', 'Rejected')
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$cancelled_count = (int)($res["total"] ?? 0);
$stmt->close();

/* =========================
   RECENT REQUESTS
========================= */
$requests = [];

$stmt = $conn->prepare("
    SELECT 
        id,
        pickup_location,
        destination,
        appointment_datetime,
        wheelchair,
        oxygen,
        companion,
        escort_required,
        status,
        created_at
    FROM requests
    WHERE patient_id = ?
    ORDER BY created_at DESC
    LIMIT 10
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}
$stmt->close();

$avatar_letter = mb_substr($full_name, 0, 1);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Adud — Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
        
    </div>

    <div class="nav-section">
        <div class="nav-section-label">Main / الرئيسية</div>

        <a class="nav-item active" href="../dashboard/dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Dashboard</span>
                <span class="label-ar">الرئيسية</span>
            </div>
        </a>

        <a class="nav-item" href="../createReq/createReq.php">
            <span class="icon">➕</span>
            <div class="nav-item-content">
                <span>New Request</span>
                <span class="label-ar">طلب جديد</span>
            </div>
        </a>

        <a class="nav-item" href="../track-trip/track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trip</span>
                <span class="label-ar">تتبع الرحلة</span>
            </div>
        </a>

        <a class="nav-item" href="../trip-history/trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الرحلات</span>
            </div>
        </a>
    </div>

    <div class="nav-section">
        <div class="nav-section-label">Account / الحساب</div>

        <a class="nav-item" href="../medical-profile/medical-profile.php">
            <span class="icon">👤</span>
            <div class="nav-item-content">
                <span>Medical Profile</span>
                <span class="label-ar">الملف الطبي</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($avatar_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($full_name); ?></div>
                <div class="role">Patient / Guardian</div>
            </div>
        </div>

        <a class="logout-btn" href="../logout.php">
            🚪 Logout / تسجيل الخروج
        </a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div class="topbar-left">
            <h1>Dashboard</h1>
            <span class="badge">Overview</span>
        </div>

        <div class="topbar-right">
            <a class="primary-btn" href="../createReq/createReq.php">
                + New Request
            </a>
        </div>
    </div>

    <p class="topbar-sub">
        Welcome back, <?php echo h($full_name); ?> / أهلاً بك
    </p>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon">🟡</div>
            <div class="stat-value"><?php echo $requested_count; ?></div>
            <div class="stat-label">Requested</div>
            <div class="stat-sub">طلبات جديدة</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">🚐</div>
            <div class="stat-value"><?php echo $active_count; ?></div>
            <div class="stat-label">Active Trips</div>
            <div class="stat-sub">رحلات نشطة</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">✅</div>
            <div class="stat-value"><?php echo $completed_count; ?></div>
            <div class="stat-label">Completed</div>
            <div class="stat-sub">رحلات مكتملة</div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">❌</div>
            <div class="stat-value"><?php echo $cancelled_count; ?></div>
            <div class="stat-label">Cancelled</div>
            <div class="stat-sub">ملغية / مرفوضة</div>
        </div>
    </div>

    <div class="section-head">
        <div>
            <h2>Recent Requests</h2>
            <p>Your latest transport requests / آخر الطلبات</p>
        </div>
    </div>

    <div class="requests-wrap">
        <?php if (count($requests) > 0): ?>
            <div class="requests-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Route</th>
                            <th>Date & Time</th>
                            <th>Requirements</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($requests as $request): ?>
                        <tr>
                            <td>#<?php echo h($request["id"]); ?></td>

                            <td>
                                <div class="route-cell">
                                    <div class="route-from"><?php echo h($request["pickup_location"]); ?></div>
                                    <div class="route-arrow">→</div>
                                    <div class="route-to"><?php echo h($request["destination"]); ?></div>
                                </div>
                            </td>

                            <td>
                                <?php echo h(date("d M Y", strtotime($request["appointment_datetime"]))); ?><br>
                                <span class="time-text"><?php echo h(date("h:i A", strtotime($request["appointment_datetime"]))); ?></span>
                            </td>

                            <td>
                                <div class="mini-tags">
                                    <?php if ($request["wheelchair"]): ?><span>♿</span><?php endif; ?>
                                    <?php if ($request["oxygen"]): ?><span>🫁</span><?php endif; ?>
                                    <?php if ($request["companion"]): ?><span>🤝</span><?php endif; ?>
                                    <?php if ($request["escort_required"]): ?><span>🏥</span><?php endif; ?>
                                    <?php if (
                                        !$request["wheelchair"] &&
                                        !$request["oxygen"] &&
                                        !$request["companion"] &&
                                        !$request["escort_required"]
                                    ): ?>
                                        <span class="no-tags">—</span>
                                    <?php endif; ?>
                                </div>
                            </td>

                            <td>
                                <span class="status-pill <?php echo statusClass($request["status"]); ?>">
                                    <?php echo h($request["status"]); ?>
                                </span>
                            </td>

                            <td>
                                <div class="action-group">
                                    <?php if ($request["status"] === "Requested"): ?>
                                        <a class="table-btn edit"
                                           href="../edit-request/edit-request.php?id=<?php echo h($request["id"]); ?>">
                                            Edit
                                        </a>

                                        <form method="POST"
                                              action="../cancel-request/cancel-request.php"
                                              onsubmit="return confirm('Are you sure you want to cancel this request?');"
                                              style="display:inline;">
                                            <input type="hidden" name="request_id" value="<?php echo h($request["id"]); ?>">
                                            <button type="submit" class="table-btn cancel">Cancel</button>
                                        </form>
                                    <?php else: ?>
                                        <a class="table-btn view"
                                           href="../track-trip/track-trip.php?id=<?php echo h($request["id"]); ?>">
                                            View
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-card">
                <div class="empty-icon">📭</div>
                <h3>No requests yet</h3>
                <p>Start by creating your first transport request.</p>
                <a class="primary-btn" href="../createReq/createReq.php">Create Request</a>
            </div>
        <?php endif; ?>
    </div>
</main>

</body>
</html>