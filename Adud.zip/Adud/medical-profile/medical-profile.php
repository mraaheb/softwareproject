<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "patient") {
    header("Location: ../login/login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$message = "";
$is_edit_mode = false;

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* =========================
   HANDLE ACTIONS
========================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";

    if ($action === "edit") {
        $is_edit_mode = true;
    } elseif ($action === "cancel") {
        $is_edit_mode = false;
    } elseif ($action === "save") {
        $is_edit_mode = true;

        $full_name  = trim($_POST["full_name"] ?? "");
        $phone      = trim($_POST["phone"] ?? "");
        $notes      = trim($_POST["notes"] ?? "");
        $wheelchair = isset($_POST["wheelchair"]) ? 1 : 0;
        $oxygen     = isset($_POST["oxygen"]) ? 1 : 0;
        $companion  = isset($_POST["companion"]) ? 1 : 0;

        if ($full_name !== "" && $phone !== "") {
            $stmt = $conn->prepare("
                UPDATE patient_guardians
                SET full_name = ?, phone = ?
                WHERE id = ?
            ");
            $stmt->bind_param("ssi", $full_name, $phone, $user_id);
            $stmt->execute();
            $stmt->close();

            $check_stmt = $conn->prepare("
                SELECT patient_id
                FROM profiles
                WHERE patient_id = ?
                LIMIT 1
            ");
            $check_stmt->bind_param("i", $user_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                $stmt = $conn->prepare("
                    UPDATE profiles
                    SET wheelchair = ?, oxygen = ?, companion = ?, notes = ?
                    WHERE patient_id = ?
                ");
                $stmt->bind_param("iiisi", $wheelchair, $oxygen, $companion, $notes, $user_id);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO profiles (patient_id, wheelchair, oxygen, companion, notes)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("iiiis", $user_id, $wheelchair, $oxygen, $companion, $notes);
                $stmt->execute();
                $stmt->close();
            }

            $check_stmt->close();

            $_SESSION["full_name"] = $full_name;
            $message = "Profile saved successfully.";
            $is_edit_mode = false;
        } else {
            $message = "Please fill in all required fields.";
            $is_edit_mode = true;
        }
    }
}

/* =========================
   LOAD USER DATA
========================= */
$stmt = $conn->prepare("
    SELECT 
        pg.full_name,
        pg.email,
        pg.phone,
        p.wheelchair,
        p.oxygen,
        p.companion,
        p.notes
    FROM patient_guardians pg
    LEFT JOIN profiles p ON pg.id = p.patient_id
    WHERE pg.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$full_name  = $user["full_name"] ?? "";
$email      = $user["email"] ?? "";
$phone      = $user["phone"] ?? "";
$wheelchair = (int)($user["wheelchair"] ?? 0);
$oxygen     = (int)($user["oxygen"] ?? 0);
$companion  = (int)($user["companion"] ?? 0);
$notes      = $user["notes"] ?? "";

$first_letter = mb_substr($full_name ?: "U", 0, 1);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Adud — Medical Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="medical-profile.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
        
    </div>

    <div class="nav-section">
        <div class="nav-section-label">Main / الرئيسية</div>

        <a class="nav-item" href="../dashboard/dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Dashboard</span>
                <span class="label-ar">الرئيسية</span>
            </div>
        </a>

        <a class="nav-item" href="../createReq/createReq.php">
            <span class="icon">➕</span>
            <div class="nav-item-content">
                <span>New Request</span>
                <span class="label-ar">طلب جديد</span>
            </div>
        </a>

        <a class="nav-item" href="../track-trip/track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trip</span>
                <span class="label-ar">تتبع الرحلة</span>
            </div>
        </a>

        <a class="nav-item" href="../trip-history/trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الرحلات</span>
            </div>
        </a>
    </div>

    <div class="nav-section">
        <div class="nav-section-label">Account / الحساب</div>

        <a class="nav-item active" href="../medical-profile/medical-profile.php">
            <span class="icon">👤</span>
            <div class="nav-item-content">
                <span>Medical Profile</span>
                <span class="label-ar">الملف الطبي</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($first_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($full_name); ?></div>
                <div class="role">Patient / Guardian</div>
            </div>
        </div>

        <a class="logout-btn" href="../logout.php">
            🚪 Logout / تسجيل الخروج
        </a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div class="topbar-left">
            <h1>Medical Profile</h1>
            <span class="badge">Profile</span>
        </div>

        <a class="primary-btn" href="../dashboard/dashboard.php">← Back</a>
    </div>

    <p class="topbar-sub">
        Manage your personal and mobility requirements / أدر معلوماتك ومتطلبات التنقل
    </p>

    <?php if ($message !== ""): ?>
        <div class="success-toast show">
            ✅ <?php echo h($message); ?>
        </div>
    <?php endif; ?>

    <div class="profile-grid">
        <div class="profile-summary">
            <div class="avatar-big"><?php echo h($first_letter); ?></div>
            <div class="profile-name"><?php echo h($full_name); ?></div>
            <div class="profile-role">Patient / مريضة</div>
            <div class="profile-badge">✓ Profile Complete</div>

            <div class="info-rows">
                <div class="info-row">
                    <span class="info-icon">📧</span>
                    <span class="info-label">Email</span>
                    <span class="info-val"><?php echo h($email); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-icon">📱</span>
                    <span class="info-label">Phone</span>
                    <span class="info-val"><?php echo h($phone); ?></span>
                </div>

                <div class="info-row">
                    <span class="info-icon">♿</span>
                    <span class="info-label">Wheelchair</span>
                    <span class="info-val <?php echo $wheelchair ? 'highlight-green' : 'highlight-gray'; ?>">
                        <?php echo $wheelchair ? '✓ Required' : '✗ Not needed'; ?>
                    </span>
                </div>

                <div class="info-row">
                    <span class="info-icon">🤝</span>
                    <span class="info-label">Companion</span>
                    <span class="info-val <?php echo $companion ? 'highlight-green' : 'highlight-gray'; ?>">
                        <?php echo $companion ? '✓ Required' : '✗ Not needed'; ?>
                    </span>
                </div>

                <div class="info-row">
                    <span class="info-icon">🫁</span>
                    <span class="info-label">Oxygen</span>
                    <span class="info-val <?php echo $oxygen ? 'highlight-green' : 'highlight-gray'; ?>">
                        <?php echo $oxygen ? '✓ Required' : '✗ Not needed'; ?>
                    </span>
                </div>
            </div>
        </div>

        <div class="profile-card">
            <div class="card-header">
                <div>
                    <h2>Profile Details / تفاصيل الملف</h2>
                    <p>Your details auto-fill future transport requests</p>
                </div>

                <?php if (!$is_edit_mode): ?>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="edit">
                        <button type="submit" class="edit-btn">✏️ Edit / تعديل</button>
                    </form>
                <?php endif; ?>
            </div>

            <form method="POST" action="">
                <div class="card-body">
                    <div class="section-label">Personal Information / المعلومات الشخصية</div>

                    <div class="form-grid2">
                        <div class="field">
                            <label>Full Name / الاسم</label>
                            <input type="text" name="full_name" value="<?php echo h($full_name); ?>" <?php echo !$is_edit_mode ? 'disabled' : ''; ?> required>
                        </div>

                        <div class="field">
                            <label>Phone / الهاتف</label>
                            <input type="tel" name="phone" value="<?php echo h($phone); ?>" <?php echo !$is_edit_mode ? 'disabled' : ''; ?> required>
                        </div>

                        <div class="field">
                            <label>Email / البريد</label>
                            <input type="email" value="<?php echo h($email); ?>" disabled>
                        </div>

                        <div class="field">
                            <label>Status / الحالة</label>
                            <input type="text" value="Active Profile / ملف نشط" disabled>
                        </div>
                    </div>

                    <div class="section-label">Mobility Requirements / متطلبات التنقل</div>

                    <div class="mobility-grid">
                        <label class="mobility-option <?php echo $wheelchair ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>">
                            <input class="hidden-checkbox" type="checkbox" name="wheelchair" value="1" <?php echo $wheelchair ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>>
                            <div class="mobility-icon">♿</div>
                            <div class="mobility-label">Wheelchair</div>
                            <div class="mobility-label-ar">كرسي متحرك</div>
                            <div class="mobility-check"></div>
                        </label>

                        <label class="mobility-option <?php echo $oxygen ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>">
                            <input class="hidden-checkbox" type="checkbox" name="oxygen" value="1" <?php echo $oxygen ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>>
                            <div class="mobility-icon">🫁</div>
                            <div class="mobility-label">Oxygen Support</div>
                            <div class="mobility-label-ar">دعم أكسجين</div>
                            <div class="mobility-check"></div>
                        </label>

                        <label class="mobility-option <?php echo $companion ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>">
                            <input class="hidden-checkbox" type="checkbox" name="companion" value="1" <?php echo $companion ? 'checked' : ''; ?> <?php echo !$is_edit_mode ? 'disabled' : ''; ?>>
                            <div class="mobility-icon">🤝</div>
                            <div class="mobility-label">Companion Seat</div>
                            <div class="mobility-label-ar">مقعد مرافق</div>
                            <div class="mobility-check"></div>
                        </label>
                    </div>

                    <div class="section-label">Additional Notes / ملاحظات إضافية</div>

                    <div class="field">
                        <textarea name="notes" placeholder="Write any transport or medical note here... / اكتبي أي ملاحظات هنا" <?php echo !$is_edit_mode ? 'disabled' : ''; ?>><?php echo h($notes); ?></textarea>
                    </div>
                </div>

                <?php if ($is_edit_mode): ?>
                    <div class="card-footer">
                        <button type="submit" name="action" value="cancel" class="btn-cancel-form">Cancel / إلغاء</button>
                        <button type="submit" name="action" value="save" class="btn-save">Save Changes / حفظ التغييرات</button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</main>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const options = document.querySelectorAll(".mobility-option");

    options.forEach(function (option) {
        const checkbox = option.querySelector('input[type="checkbox"]');
        const checkMark = option.querySelector(".mobility-check");

        function updateState() {
            if (checkbox.checked) {
                option.classList.add("checked");
                if (checkMark) checkMark.textContent = "✓";
            } else {
                option.classList.remove("checked");
                if (checkMark) checkMark.textContent = "";
            }
        }

        updateState();
        checkbox.addEventListener("change", updateState);
    });
});
</script>

</body>
</html>