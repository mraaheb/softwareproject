<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION["user_id"]) ||
    !isset($_SESSION["role"]) ||
    $_SESSION["role"] !== "provider"
) {
    header("Location: ../login/login.php");
    exit;
}

$provider_id = (int)$_SESSION["user_id"];
$provider_name = $_SESSION["full_name"] ?? "Provider";

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getStatusArabic($status) {
    switch ($status) {
        case 'Requested': return 'تم الطلب';
        case 'Assigned': return 'تم التعيين';
        case 'Picked Up': return 'تم الاستلام';
        case 'Arrived': return 'تم الوصول';
        case 'Completed': return 'مكتمل';
        case 'Cancelled': return 'ملغي';
        case 'Rejected': return 'مرفوض';
        default: return '—';
    }
}

function getStatusClass($status) {
    switch ($status) {
        case 'Completed': return 'status-completed';
        case 'Cancelled':
        case 'Rejected': return 'status-cancelled';
        case 'Picked Up':
        case 'Arrived': return 'status-progress';
        case 'Assigned': return 'status-assigned';
        default: return 'status-requested';
    }
}

function formatDateTimeValue($datetime) {
    if (!$datetime || strtotime($datetime) === false) return '—';
    return date("Y-m-d H:i", strtotime($datetime));
}

$requests = [];

$stmt = $conn->prepare("
    SELECT
        r.id,
        r.pickup_location,
        r.destination,
        r.appointment_datetime,
        r.status,
        pg.full_name AS patient_name
    FROM requests r
    INNER JOIN patient_guardians pg ON pg.id = r.patient_id
    WHERE r.provider_id = ?
    ORDER BY r.updated_at DESC, r.id DESC
");
$stmt->bind_param("i", $provider_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}
$stmt->close();

$avatar_letter = mb_substr($provider_name, 0, 1);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adud — Provider Track Trips</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../track-trip/provider-track-trip.css?v=5">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
    </div>

    <div class="provider-badge">🔑 Service Provider</div>

    <div class="nav-section">
        <div class="nav-section-label">Main / الرئيسية</div>

        <a class="nav-item" href="../provider-dashboard/provider-dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Provider Dashboard</span>
                <span class="label-ar">لوحة المزود</span>
            </div>
        </a>

        <a class="nav-item active" href="../track-trip/provider-track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trips</span>
                <span class="label-ar">تتبع الرحلات</span>
            </div>
        </a>

        <a class="nav-item" href="../trip-history/provider-trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الرحلات</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($avatar_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($provider_name); ?></div>
                <div class="role">Service Provider ✓</div>
            </div>
        </div>

        <button class="logout-btn" onclick="window.location.href='../logout.php'">
            🚪 Logout / تسجيل الخروج
        </button>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div>
            <h1>Track Trips / تتبع الرحلات</h1>
            <p>Choose any request to view its timeline details</p>
        </div>

        <button class="back-btn" type="button" onclick="location.href='../provider-dashboard/provider-dashboard.php'">
            ← Back / رجوع
        </button>
    </div>

    <div class="list-card">
        <div class="card-header">
            <h2>All Provider Requests / كل طلبات المزود</h2>
            <p>Click the button to open timeline details</p>
        </div>

        <div class="card-body">
            <?php if (empty($requests)): ?>
                <div class="empty-state">
                    <p>No requests found for this provider / لا توجد طلبات لهذا المزود</p>
                </div>
            <?php else: ?>
                <div class="request-list">
                    <?php foreach ($requests as $request): ?>
                        <div class="request-row">
                            <div class="request-main">
                                <div class="request-id">#<?php echo h($request["id"]); ?></div>

                                <div class="request-info">
                                    <div class="request-patient"><?php echo h($request["patient_name"]); ?></div>
                                    <div class="request-route"><?php echo h($request["pickup_location"]); ?> → <?php echo h($request["destination"]); ?></div>
                                    <div class="request-date"><?php echo h(formatDateTimeValue($request["appointment_datetime"])); ?></div>
                                </div>
                            </div>

                            <div class="request-side">
                                <span class="status-badge <?php echo h(getStatusClass($request["status"])); ?>">
                                    <?php echo h($request["status"]); ?> / <?php echo h(getStatusArabic($request["status"])); ?>
                                </span>

                                <a class="details-btn" href="../track-trip/provider-track-details.php?id=<?php echo (int)$request["id"]; ?>">
                                    Timeline Details
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

</body>
</html>