<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (session_status() === PHP_SESSION_NONE) session_start();

if (
    !isset($_SESSION["user_id"]) ||
    !isset($_SESSION["role"]) ||
    !in_array($_SESSION["role"], ["user","patient"], true)
) {
    header("Location: ../login/login.php");
    exit;
}

$patient_id = (int)$_SESSION["user_id"];
$full_name  = $_SESSION["full_name"] ?? "Patient";

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function arStatus($s){
    return [
        'Requested'=>'تم الطلب',
        'Assigned'=>'تم التعيين',
        'Picked Up'=>'تم الاستلام',
        'Arrived'=>'تم الوصول',
        'Completed'=>'مكتمل',
        'Cancelled'=>'ملغي',
        'Rejected'=>'مرفوض'
    ][$s] ?? '—';
}

function statusClass($s){
    if ($s==='Completed') return 'status-completed';
    if (in_array($s,['Cancelled','Rejected'],true)) return 'status-cancelled';
    if (in_array($s,['Picked Up','Arrived'],true)) return 'status-progress';
    if ($s==='Assigned') return 'status-assigned';
    return 'status-requested';
}

function fmtDT($d){
    return (!$d || strtotime($d)===false) ? '—' : date("Y-m-d H:i", strtotime($d));
}

/* --- GET user requests --- */
$rows = [];
$stmt = $conn->prepare("
    SELECT id, pickup_location, destination, appointment_datetime, status
    FROM requests
    WHERE patient_id = ?
    ORDER BY updated_at DESC, id DESC
");
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$res = $stmt->get_result();
while ($r = $res->fetch_assoc()) $rows[] = $r;
$stmt->close();

$avatar = mb_substr($full_name,0,1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Requests</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;600;700&display=swap" rel="stylesheet">
<!-- نفس ستايل البروفايدر -->
<link rel="stylesheet" href="../track-trip/track-trip.css?v=5">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
    </div>

    <div class="nav-section">
        <div class="nav-section-label">MAIN / الرئيسية</div>

        <a class="nav-item" href="../dashboard/dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Dashboard</span>
                <span class="label-ar">الرئيسية</span>
            </div>
        </a>

        <a class="nav-item" href="../createReq/createReq.php">
            <span class="icon">➕</span>
            <div class="nav-item-content">
                <span>New Request</span>
                <span class="label-ar">طلب جديد</span>
            </div>
        </a>

        <a class="nav-item active" href="../track-trip/track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trip</span>
                <span class="label-ar">تتبع الرحلة</span>
            </div>
        </a>

        <a class="nav-item " href="../trip-history/trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الرحلات</span>
            </div>
        </a>
    </div>

    <div class="nav-section">
        <div class="nav-section-label">ACCOUNT / الحساب</div>

        <a class="nav-item" href="../medical-profile/medical-profile.php">
            <span class="icon">👤</span>
            <div class="nav-item-content">
                <span>Medical Profile</span>
                <span class="label-ar">الملف الطبي</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($avatar_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($full_name); ?></div>
                <div class="role">Patient / Guardian</div>
            </div>
        </div>

        <a class="logout-btn" href="../logout.php">
            🚪 Logout / تسجيل الخروج
        </a>
    </div>
</aside>

<main class="main">
  <div class="topbar">
    <div>
      <h1>My Requests</h1>
      <p>Click any request to view timeline</p>
    </div>
  </div>

  <div class="list-card">
    <div class="card-header">
      <h2>All Requests</h2>
    </div>

    <div class="card-body">
      <?php if (empty($rows)): ?>
        <div class="empty-state">No requests</div>
      <?php else: ?>
        <div class="request-list">
        <?php foreach($rows as $r): ?>
          <div class="request-row">

            <div class="request-main">
              <div class="request-id">#<?=h($r["id"])?></div>

              <div class="request-info">
                <div class="request-patient">My Request</div>
                <div class="request-route">
                  <?=h($r["pickup_location"])?> → <?=h($r["destination"])?>
                </div>
                <div class="request-date"><?=h(fmtDT($r["appointment_datetime"]))?></div>
              </div>
            </div>

            <div class="request-side">
              <span class="status-badge <?=statusClass($r["status"])?>">
                <?=h($r["status"])?> / <?=h(arStatus($r["status"]))?>
              </span>

              <a class="details-btn"
                 href="track-trip-details.php?id=<?=(int)$r["id"]?>">
                 Details
              </a>
            </div>

          </div>
        <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>
</body>
</html>