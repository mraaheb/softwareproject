<?php
require_once "../includes/config.php";
require_once "../includes/db.php";
require_once "../includes/session.php";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION["user_id"]) ||
    !isset($_SESSION["role"]) ||
    !in_array($_SESSION["role"], ["user", "patient"], true)
) {
    header("Location: ../login/login.php");
    exit;
}

$patient_id = (int)$_SESSION["user_id"];
$patient_name = $_SESSION["full_name"] ?? "Patient";
$request_id = (int)($_GET["id"] ?? 0);

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getStatusArabic($status) {
    switch ($status) {
        case 'Requested': return 'تم الطلب';
        case 'Assigned': return 'تم التعيين';
        case 'Picked Up': return 'تم الاستلام';
        case 'Arrived': return 'تم الوصول';
        case 'Completed': return 'مكتمل';
        case 'Cancelled': return 'ملغي';
        case 'Rejected': return 'مرفوض';
        default: return $status ?: '—';
    }
}

function getStatusNoteFallback($status) {
    switch ($status) {
        case 'Requested': return 'Transport request submitted successfully';
        case 'Assigned': return 'Trip accepted and assigned';
        case 'Picked Up': return 'Patient has been picked up';
        case 'Arrived': return 'Patient arrived at destination';
        case 'Completed': return 'Trip completed successfully';
        case 'Cancelled': return 'Trip has been cancelled';
        case 'Rejected': return 'Trip has been rejected';
        default: return 'Status updated';
    }
}

function getStatusThemeClass($status) {
    if ($status === 'Completed') return 'completed';
    if ($status === 'Cancelled' || $status === 'Rejected') return 'cancelled';
    return 'assigned';
}

function formatTimeValue($datetime) {
    if (!$datetime || strtotime($datetime) === false) return '—';
    return date("Y-m-d — H:i", strtotime($datetime));
}

function formatTimelineTime($datetime) {
    if (!$datetime || strtotime($datetime) === false) return '⏳ Pending';
    return date("Y-m-d H:i", strtotime($datetime));
}

function mobilityItems($request) {
    $items = [];
    if (!empty($request["wheelchair"])) $items[] = "Wheelchair";
    if (!empty($request["oxygen"])) $items[] = "Oxygen";
    if (!empty($request["companion"])) $items[] = "Companion";
    return $items;
}

$request = null;
$timeline = [];

if ($request_id > 0) {
    $stmt = $conn->prepare("
        SELECT
            r.id,
            r.pickup_location,
            r.destination,
            r.appointment_datetime,
            r.status,
            r.escort_required,
            r.wheelchair,
            r.oxygen,
            r.companion,
            sp.provider_name,
            sp.full_name AS provider_full_name,
            e.full_name AS escort_name,
            e.phone AS escort_phone,
            e.notes AS escort_notes
        FROM requests r
        LEFT JOIN service_providers sp ON sp.id = r.provider_id
        LEFT JOIN escorts e ON e.id = r.escort_id
        WHERE r.id = ? AND r.patient_id = ?
        LIMIT 1
    ");
    $stmt->bind_param("ii", $request_id, $patient_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $request = $result->fetch_assoc();
    }
    $stmt->close();
}

if ($request) {
    $timeline_stmt = $conn->prepare("
        SELECT status, created_at
        FROM trip_status
        WHERE request_id = ?
        ORDER BY id ASC
    ");
    $timeline_stmt->bind_param("i", $request_id);
    $timeline_stmt->execute();
    $timeline_result = $timeline_stmt->get_result();

    while ($row = $timeline_result->fetch_assoc()) {
        $timeline[] = $row;
    }
    $timeline_stmt->close();
}

$avatar_letter = mb_substr($patient_name, 0, 1);
$current_status = $request["status"] ?? "";
$current_status_note = $current_status ? getStatusNoteFallback($current_status) : "Current workflow status";
$mobility = $request ? mobilityItems($request) : [];

$timeline_map = [];
foreach ($timeline as $item) {
    $timeline_map[$item["status"]] = $item;
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Adud — Patient Track Details</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&family=DM+Serif+Display&display=swap" rel="stylesheet"/>
    <link rel="stylesheet" href="../track-trip/provider-track-details.css?v=20">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-brand">
        <div class="logo-box">
            <img src="../images/logo.png" alt="ADUD Logo">
        </div>
    </div>

    
    <div class="nav-section">
        <div class="nav-section-label">Main / الرئيسية</div>

        <a class="nav-item" href="../dashboard/dashboard.php">
            <span class="icon">🏠</span>
            <div class="nav-item-content">
                <span>Dashboard</span>
                <span class="label-ar">لوحة المستخدم</span>
            </div>
        </a>

        <a class="nav-item active" href="../track-trip/track-trip.php">
            <span class="icon">📍</span>
            <div class="nav-item-content">
                <span>Track Trips</span>
                <span class="label-ar">تتبع الطلبات</span>
            </div>
        </a>

        <a class="nav-item" href="../trip-history/trip-history.php">
            <span class="icon">📋</span>
            <div class="nav-item-content">
                <span>Trip History</span>
                <span class="label-ar">سجل الطلبات</span>
            </div>
        </a>
    </div>

    <div class="sidebar-footer">
        <div class="user-card">
            <div class="user-avatar"><?php echo h($avatar_letter); ?></div>
            <div class="user-info">
                <div class="name"><?php echo h($patient_name); ?></div>
                <div class="role">Patient / User ✓</div>
            </div>
        </div>

        <button class="logout-btn" onclick="window.location.href='../logout.php'">
            🚪 Logout / تسجيل الخروج
        </button>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div>
            <h1>Request Details / تفاصيل الطلب</h1>
            <p>View selected request timeline and details</p>
        </div>

        <button class="back-btn" type="button" onclick="location.href='../track-trip/track-trip.php'">
            ← Back to List / رجوع للقائمة
        </button>
    </div>

    <?php if (!$request): ?>
        <div class="info-card">
            <div class="card-body">
                <p>No request found for this patient / لا يوجد طلب لهذا المستخدم</p>
            </div>
        </div>
    <?php else: ?>
    <div class="track-grid">
        <section>
            <div class="info-card">
                <div class="card-header">
                    <h2>Request Information / معلومات الطلب</h2>
                    <p>Your transport request details</p>
                </div>

                <div class="card-body">
                    <div class="req-id"># Request <?php echo h($request["id"]); ?></div>

                    <div class="detail-row">
                        <div class="detail-icon">📍</div>
                        <div class="detail-info">
                            <div class="label">Pickup / الاستلام</div>
                            <div class="value"><?php echo h($request["pickup_location"] ?: "—"); ?></div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="detail-icon">🏥</div>
                        <div class="detail-info">
                            <div class="label">Destination / الوجهة</div>
                            <div class="value"><?php echo h($request["destination"] ?: "—"); ?></div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="detail-icon">📅</div>
                        <div class="detail-info">
                            <div class="label">Date &amp; Time / التاريخ والوقت</div>
                            <div class="value"><?php echo h(formatTimeValue($request["appointment_datetime"])); ?></div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="detail-icon">🚐</div>
                        <div class="detail-info">
                            <div class="label">Service Provider / مزود الخدمة</div>
                            <div class="value">
                                <?php
                                $provider_display = $request["provider_name"] ?: $request["provider_full_name"] ?: "Not assigned yet";
                                echo h($provider_display);
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="detail-row">
                        <div class="detail-icon">🏥</div>
                        <div class="detail-info">
                            <div class="label">Escort / المرافق</div>
                            <div class="value"><?php echo !empty($request["escort_name"]) ? h($request["escort_name"]) : "None"; ?></div>
                        </div>
                    </div>

                    <div class="status-current <?php echo h(getStatusThemeClass($current_status)); ?>">
                        <div class="status-dot"></div>
                        <div class="status-text">
                            <div class="main-st"><?php echo h($current_status . " / " . getStatusArabic($current_status)); ?></div>
                            <div class="sub-st"><?php echo h($current_status_note); ?></div>
                        </div>
                    </div>

                    <div class="mobility-section">
                        <div class="section-title">Mobility Requirements</div>
                        <div class="mobility-tags">
                            <?php if (empty($mobility)): ?>
                                <span class="mob-tag">No special requirements</span>
                            <?php else: ?>
                                <?php foreach ($mobility as $tag): ?>
                                    <span class="mob-tag"><?php echo h($tag); ?></span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="escort-info">
                        <?php if (!empty($request["escort_name"])): ?>
                            <h4>🏥 Escort Assigned / تم تعيين المرافق</h4>
                            <div class="escort-row"><span>Name:</span> <?php echo h($request["escort_name"]); ?></div>
                            <div class="escort-row"><span>Phone:</span> <?php echo h($request["escort_phone"] ?: "—"); ?></div>
                            <div class="escort-row"><span>Notes:</span> <?php echo h($request["escort_notes"] ?: "—"); ?></div>
                        <?php elseif (!empty($request["escort_required"])): ?>
                            <h4>🏥 Escort Requested / تم طلب المرافق</h4>
                            <div class="escort-row"><span>Status:</span> Waiting for assignment</div>
                        <?php else: ?>
                            <h4>🏥 Escort / المرافق</h4>
                            <div class="escort-row"><span>Status:</span> Not requested</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="timeline-card">
            <div class="card-header">
                <h2>Trip Timeline / الجدول الزمني</h2>
                <p>All request and trip updates with timestamps</p>
            </div>

            <div class="timeline-body">
                <div class="timeline">
                    <?php
                    $workflow = ['Requested', 'Assigned', 'Picked Up', 'Arrived', 'Completed'];
                    $current_index = array_search($current_status, $workflow, true);

                    foreach ($workflow as $index => $status):
                        $item = $timeline_map[$status] ?? null;

                        if (in_array($current_status, ['Cancelled', 'Rejected'], true)) {
                            $last_done_index = -1;
                            foreach ($workflow as $wIndex => $wStatus) {
                                if (isset($timeline_map[$wStatus])) {
                                    $last_done_index = $wIndex;
                                }
                            }
                            $is_current = false;
                            $is_done = ($index <= $last_done_index);
                            $is_pending = !$is_done;
                        } else {
                            $is_current = ($current_status === $status);
                            $is_done = ($current_index !== false && $index < $current_index);
                            $is_pending = !$is_current && !$is_done;
                        }
                    ?>
                        <div class="timeline-item <?php echo $is_done ? 'done-line' : ($is_current ? 'active-line' : ''); ?>">
                            <div class="tl-dot <?php echo $is_done ? 'done' : ($is_current ? 'active' : 'pending'); ?>">
                                <?php echo $is_done ? '✓' : ($is_current ? '●' : ''); ?>
                            </div>
                            <div class="tl-content">
                                <div class="tl-title <?php echo $is_current ? 'active-text' : ($is_pending ? 'pending-text' : ''); ?>">
                                    <?php echo h($status . ' / ' . getStatusArabic($status) . ($is_current ? ' ← Current' : '')); ?>
                                </div>
                                <div class="tl-sub"><?php echo h(getStatusNoteFallback($status)); ?></div>
                                <div class="tl-time <?php echo $is_pending ? 'pending-time' : ''; ?>">
                                    <?php
                                    if ($item) {
                                        echo h(formatTimelineTime($item["created_at"]));
                                    } elseif ($is_done) {
                                        echo '✓ Done';
                                    } else {
                                        echo '⏳ Pending';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <?php if (in_array($current_status, ['Cancelled', 'Rejected'], true)): ?>
                        <?php $cancel_item = $timeline_map[$current_status] ?? null; ?>
                        <div class="timeline-item cancel-final">
                            <div class="tl-dot done">✕</div>
                            <div class="tl-content">
                                <div class="tl-title cancel-text">
                                    <?php echo h($current_status . ' / ' . getStatusArabic($current_status)); ?>
                                </div>
                                <div class="tl-sub"><?php echo h(getStatusNoteFallback($current_status)); ?></div>
                                <div class="tl-time"><?php echo $cancel_item ? h(formatTimelineTime($cancel_item["created_at"])) : '—'; ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
    <?php endif; ?>
</main>

</body>
</html>